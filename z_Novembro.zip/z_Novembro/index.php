<?php 
    header("location: ./html/login.html");
?>