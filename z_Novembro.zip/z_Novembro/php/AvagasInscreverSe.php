<?php
    session_start();
    include("./conexao.php");

    $num = $_POST['n'];
    $busca = mysqli_query($con, "SELECT * FROM vaga WHERE aberta = 1 LIMIT 6 OFFSET $num");
    $resultado2 = mysqli_fetch_row($busca);
    $res = "";
    
        if (empty($resultado2) || !$resultado2 || $resultado2 == "" || $resultado2 == null || $resultado2 == " " && $num <=1) {
            $num = mysqli_num_rows($busca);
            $res= $res.
            "<div class=\"respostaElse\">
                <h1>Ao que parece você não possui anúncios de vagas</h1>
                <h3>Clique <a href=\"../../php/criarVagas.php\">aqui</a> para iniciar sua jornada!</h3>
            </div>";
        }
        
        else{
            $busca = mysqli_query($con, "SELECT * FROM vaga WHERE aberta = 1 LIMIT 6 OFFSET $num");
    
            $resultado;
            
            while($resultado = mysqli_fetch_row($busca)){
                $cnpj = $resultado[7];
                $id_vaga = $resultado[0];
                $buscaLogo1 = mysqli_query($con, "SELECT logo FROM empresa where cnpj ='$cnpj'");
                $buscaLogo = mysqli_fetch_row($buscaLogo1);

                    $res = $res. 
                    "<div class=\"cardVaga\">
                    <div class=\"imgLogo img_conteiner\">
                        <img src=".$buscaLogo[0]." alt=\"logo\">
                    </div>
                    <div class=\"informacoes_da_vaga vaga\">
                        <p><strong>".$resultado[1]."Analista de departamento</strong></p><br>
                        <div class=\"oferta spaceAround\">
                            <div class=\"salario\"><p>".$resultado[8]."R$ 3.500,00</p></div>
                            <div><p>|</p></div>
                            <div class=\"local\"><p>".$resultado[10]."São Paulo, SP</p></div>
                        </div>
                    </div>
                    <div class=\"flexC detalhes_Oferta spaceEvenly\">
                        <button class=\"cadastrar\">Cadastrar-se</button>
                        <button>Mais Detalhes</button>
                    </div>
                </div>";              
                      
            }
       }
            
       
    
        echo $res;
    
    /* colocar lógica de banco */
    
    

?>