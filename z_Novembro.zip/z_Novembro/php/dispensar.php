<?php 
    $cpf = $_GET['cpf'];

    
?>