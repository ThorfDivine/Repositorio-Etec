let width = window.innerHeight
    console.log(width);